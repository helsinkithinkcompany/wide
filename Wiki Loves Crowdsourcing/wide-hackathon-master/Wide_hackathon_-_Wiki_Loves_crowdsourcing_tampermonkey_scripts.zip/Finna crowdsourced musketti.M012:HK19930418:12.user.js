// ==UserScript==
// @name         Finna crowdsourced musketti.M012:HK19930418:12
// @namespace    https://www.finna.fi/Record
// @version      0.1
// @description  Inject
// @author       You
// @match        https://www.finna.fi/Record/musketti.M012:HK19930418:12*
// @grant        GM_addStyle
// @run-at document-end

// ==/UserScript==

(function() {
    'use strict';
    /*
    var observer = new MutationObserver(function(mutations) {
    if($('.leaflet-container').length > 0){
        $('.leaflet-container').hide();
    }
    });
    observer.observe(document.body, {
        subtree: true,
        childList: true,
        attributes: false,
        characterData: false,
        attributeOldValue: false,
        characterDataOldValue: false
    });*/

     function closePopup(e) {
         $("div.imagepopup-holder").remove();
         $("div.imagepopup-container").remove();
     }

     function createPopup(e) {
         var holder=$("<div>");
         holder.addClass("imagepopup-holder");
         holder.click(closePopup);

         var container=$("<div>");
         container.addClass("imagepopup-container");

         var closebutton=$('<button title="sulje" type="button" class="mfp-close">×</button>');
         closebutton.css('color', '#333');
         closebutton.click(closePopup);


/*         container.css("margin", "10em");
         container.css("padding", "2em");
         container.css("width", "100%");*/

//         container.css("backgroud-color", "white");

         holder.css("position", "absolute");
         holder.css("top", "0em");
         holder.css("left", "0em");
         holder.css("height", "500%");
         holder.css("background", "black");
         holder.css("z-index", "1050");
         holder.css("opacity", 0.7);
         container.css("background", "white")
         container.css("margin", "2%");
         container.css("margin-left", "10%");
         container.css("margin-right", "10%");
         container.css("width", "1050px");
         container.css("height", "600px");

//         container.css("height", "1000px");
         container.css("opacity", 1);
         container.css("z-index", "1070");
         container.css("position", "absolute");
         container.css("top", "0em");
         container.css("left", "0em");
         container.css("overflow", "hidden");


         var right_content=$("<div>").addClass("content imagepopup-holder imagepopup-container");
         right_content.css("width", "400px");

         // title
         var title=$("<h3>").addClass("title").text(e.find("h3.record-title").text());

         //
         var authoranddates=$("<div>").addClass("author-and-dates").html(e.find("div.record-core-metadata").html());
         var building=$("<div>").addClass("building").text(e.find("tr.recordInstitution").find("td").text());
         var summary=$("<div>").addClass("summary").text(e.find("p.summary").text());
         var buttons=$("<div>").addClass("popup-link-buttons");
         var recordlink=$("<div>").addClass("record-link").html('<a href="/Record/musketti.M012:HK19930418:12"><i class="fa fa-arrow-circle-right"></i><span>Näytä tarkat tiedot</span></a>');;
         var saverecordlink=$("<div>").addClass("save-record-link").html('<a href="/Record/musketti.M012:HK19930418:10/Save" class="save-record" data-lightbox="" data-id="musketti.M012:HK19930418:10" title="Lisää suosikkeihin"><i class="fa fa-heart"></i><span>Lisää suosikkeihin</span></a>');
         var openlink=$("<div>").addClass("open-link").html(e.find("div.image-link").html());

         buttons.append(recordlink);
         buttons.append(saverecordlink);
         buttons.append(openlink);


         var imagerights=$("<div>").addClass("image-rights");
         imagerights.css("padding-bottom", "0.5em");
         imagerights.append('<span>Kuvan käyttöoikeudet:</span> <a target="_blank" href="http://creativecommons.org/licenses/by/4.0/deed.fi">CC BY 4.0</a></div><div class="more-link copyright-link"> <a data-mode="1" href="">Lisää<i class="fa fa-arrow-down"></i></a></div>');

         var recordprovidedby=$("<div>").addClass("recordProvidedBy").html('<h4 class="record-organisation-header">Aineistosta vastaa</h4><div class="record-organisation-box"><ul class="record-type organisations"><li class="record-organisation"><span class="organisation-name">Wikimedia Suomi / Wide</span><ul class="record-organisation-info"><li class="organisation-page-link done" data-organisation="Wikimedia Suomi / Wide" data-organisation-name="Wikimedia Suomi / Wide"></li><li><a href="/Record/musketti.M012:HK19930418:10/Feedback" data-lightbox="" class="btn btn-primary feedback-record">Ota yhteyttä</a></li></ul></li></ul></div></div>');

         right_content.append(title);
         right_content.append(authoranddates);
         right_content.append(building);
         right_content.append(summary);
         right_content.append(buttons);
         right_content.append(imagerights);
         right_content.append(recordprovidedby);

         container.append(closebutton);
         container.append('<iframe frameborder="0" class="juxtapose" width="640" height="500" src="https://cdn.knightlab.com/libs/juxtapose/latest/embed/index.html?uid=e24f318e-da12-11e8-9dba-0edaf8f81e27"></iframe>');

         container.append(right_content);
         $("body").append(holder);
         $("body").append(container);
     }


//    $(document).ready(function() {

      var e=$("div.record-main");

      e.find("img.recordcover").attr("src", "https://ajapaik.ee/media/uploads/Ajapaik-rephoto-2018-09-21_12-51-08.jpg");
      e.find("div.image-link").find("a").attr("href", "https://ajapaik.ee/media/uploads/Ajapaik-rephoto-2018-09-21_12-51-08.jpg");
      e.find("div.image-link").find("a").attr("download", "https://ajapaik.ee/media/uploads/Ajapaik-rephoto-2018-09-21_12-51-08.jpg");
      e.find("div.open-link").append("<span style='color: #919191;font-size: .8em;'>( 3264 X 2448 )</span>");
      e.find("div.record-organisation-box").find("span.organisation-name").text("Wikimedia Suomi / Wide");

      e.find("h3.record-title").text("Jälleenvalokuva valokuvasta punavankeja Suomenlinnan IV piirin Susisaaren vankileirillä musketti.M012:HK19930418:11");

      e.find("div.record-core-metadata").find("a").text("Teemu Ikonen");
      e.find("div.record-core-metadata").html(e.find("div.record-core-metadata").html().replace("1918", "21.9.2018"));
      e.find("p.summary").text("Jälleenvalokuva valokuvasta punavankeja Suomenlinnan IV piirin Susisaaren vankileirillä musketti.M012:HK19930418:11");
      e.find("table.record-details").html(e.find("table.record-details").html().replace(/1918/g, "21.9.2018"));

      e.find("tr.recordFormat").find("td").text("Jälleenvalokuva");
      e.find("tr.recordFormat").after("<tr><th>Alkuperäinen kuva</th><td><a href='https://www.finna.fi/Record/musketti.M012:HK19930418:11'>HK19930418:11</a></td></tr>");

      e.find("tr.recordInstitution").find("td").text("Wikimedia Suomi / Wide");
      e.find("tr.recordCollection").find("td").text("Rephotographs");
      e.find("tr.recordMeasurements").hide();
      e.find("tr.recordEvents").find("td").html("21.9.2018<br>Susisaari, Helsinki<br>Teemu Ikonen, kuvaaja");
      e.find("tr.recordSubjects").each(function(k, v) {
          if ($(v).find("th").text()=="Aiheet")
          {
              $(v).find("td").html("");
              $(v).find("td").append('<div class="subjectLine" property="keywords"><a class="backlink" title="Suomenlinna" href="/Search/Results?lookfor=%22suomenlinna%22&amp;type=Place">Suomenlinna</a></div>');
          }
      });
      e.find(".recordcover").click(function (event) { event.stopPropagation(); createPopup($("div.record-main")); });

      GM_addStyle('img.recordcover { display:block !important}');
      GM_addStyle('div.right { display:block !important}');
      GM_addStyle('span.image-dimensions { display:none !important}');
      GM_addStyle('div.large-image-sidebar { display:none !important}');



//    });

})();