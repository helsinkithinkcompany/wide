// ==UserScript==
// @name         Finna musketti.M012:HK19930418:11
// @namespace    https://www.finna.fi/Record
// @version      0.1
// @description  Inject
// @author       You
// @match        https://www.finna.fi/Record/musketti.M012:HK19930418:11*
// @grant        GM_addStyle
// @run-at document-end

// ==/UserScript==

(function() {
    'use strict';
//    $(document).ready(function() {

      var e=$("div.record-main");
      e.find("tr.recordEvents").before("<tr><th>Muita versioita</th><td><a href='https://www.finna.fi/Record/musketti.M012:HK19930418:12'>HK19930418:12</a> (jälleenvalokuva)</td></tr>");

      GM_addStyle('img.recordcover { display:block !important}');
      GM_addStyle('div.right { display:block !important}');
      GM_addStyle('div.large-image-sidebar { display:none !important}');


//    });

})();