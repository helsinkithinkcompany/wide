// ==UserScript==
// @name         Ajapaik Finna mod search hide
// @namespace    https://www.finna.fi/Search/Results
// @version      0.1
// @description  Inject
// @author       You
// @match        https://www.finna.fi/Search/Results*
// @match        https://www.finna.fi/Record/musketti.M012:HK19930418:12*

// @grant GM_addStyle
// @run-at document-end

// ==/UserScript==

(function() {
    'use strict';
     GM_addStyle('div.right { display:none !important}');
     GM_addStyle('img.recordcover { display:none !important}');
})();