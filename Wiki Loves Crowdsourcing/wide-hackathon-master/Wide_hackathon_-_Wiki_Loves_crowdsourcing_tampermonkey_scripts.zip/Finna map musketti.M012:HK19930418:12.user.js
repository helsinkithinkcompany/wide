// ==UserScript==
// @name         Finna map musketti.M012:HK19930418:12
// @namespace    https://www.finna.fi/Record
// @version      0.1
// @description  Inject
// @author       You
// @match        https://www.finna.fi/Record/musketti.M012:HK19930418:12*
// @match        https://www.finna.fi/Record/musketti.M012:HK19930418:11*
// @grant        GM_addStyle
// @require      https://ajapaik.ee/static/js/leaflet.rotatedMarker.js
// @run-at document-end

// ==/UserScript==

(function() {
    $("body").append('<script src="https://ajapaik.ee/static/js/leaflet.rotatedMarker.js" type="text/javascript"></script>');
    'use strict';
    var observer = new MutationObserver(function(mutations) {
    if($('.leaflet-container').length > 0){
        $('.leaflet-container').hide();
        $('.map-canvas').after('<div class="map-canvas-wide">XXXXXX</div>');
        var mapcanvas=$('.map-canvas-wide')
        mapcanvas.css("height", "500px");

        $('.map-canvas').remove();
//        $('.map-canvas-wide').remove();
        add_leaflet(mapcanvas.get(0));
        observer.disconnect();
        $('.leaflet-container').show();

    }
    });
    observer.observe(document.body, {
        subtree: true,
        childList: true,
        attributes: false,
        characterData: false,
        attributeOldValue: false,
        characterDataOldValue: false
    });


    function add_leaflet(target_map_canvas) {
        var tileLayer = L.tileLayer('//map-api.finna.fi/v1/rendered/{z}/{x}/{y}.png', {
            maxZoom: 18,
            tileSize: 256,
            attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>'
        });

        var drawnItems = new L.FeatureGroup();

        var markersData = [{"wkt":"POLYGON((24.951867 60.1466744,24.9536017 60.1514407,24.9561829 60.1532226,24.960873 60.1516211,25.0058051 60.1591638,25.0224191 60.1582594,25.0220439 60.1410316,25.0279881 60.1377606,25.0288446 60.1184848,25.0079479 60.1177843,24.951867 60.1466744))","title":"punavankeja Suomenlinnan IV piirin Susisaaren vankileirill\u00e4","center":{"lon":"24.9425683","lat":"60.1674086"}},{"wkt":"POLYGON ((24.7828131 60.0999549, 24.8356577 60.130414, 24.8513844 60.2249765, 24.8419098 60.2212043, 24.8347825 60.2585099, 24.8677628 60.2523073, 24.9473908 60.2784652, 24.9731653 60.2643801, 25.0209862 60.2893227, 25.0882105 60.2713417, 25.0823359 60.2496391, 25.1358461 60.2372286, 25.1598757 60.2488133, 25.1425242 60.2697779, 25.2545116 60.2952274, 25.2509121 60.2734979, 25.2273451 60.2611057, 25.240926 60.246305, 25.2014099 60.2181613, 25.2204176 60.1997262, 25.1800446 60.0987408, 25.1693516 59.9434386, 24.9423061 59.922486, 24.7828131 60.0999549))","title":"punavankeja Suomenlinnan IV piirin Susisaaren vankileirill\u00e4"}];
        var icon = L.divIcon({
            className: 'mapMarker',
            iconSize: null,
            html: '<div class="leaflet-marker-icon leaflet-zoom-animated leaflet-interactive" style="margin-left: -10px; margin-top: -30px;"><i class="fa fa-map-marker" style="position: relative; font-size: 35px; opacity: 0.8"></i></div>'
        });
        for (var i = 0; i < markersData.length; i++) {
            var marker = markersData[i];
            var item = null;
            if (marker.wkt) {
                item = omnivore.wkt.parse(marker.wkt);
            } else if (marker.polygon) {
                item = L.polygon(marker.polygon);
            } else if (marker.multipolygon) {
                item = L.multiPolygon(marker.multipolygon);
            }

            if (item) {
                item.addTo(drawnItems);
                var center;
                if (typeof marker.center !== 'undefined') {
                    center = L.latLng(marker.center.lat, marker.center.lon);
                } else {
                    center = item.getBounds().getCenter();
                }
                L.marker(center, {icon: icon}).addTo(drawnItems);
            } else if (marker.points) {
                for (var p = 0; p < marker.points.length; p++) {
                    L.marker([marker.points[p].lat, marker.points[p].lon], {icon: icon}).addTo(drawnItems);
                }
            }
        }

                               var map = new L.Map(target_map_canvas, {
                                   layers: [tileLayer, drawnItems],
                                   center: drawnItems.getBounds().getCenter(),
                                   zoom: 5,
                                   zoomControl: false
                               });
                        finna.map.initMapZooming(map);


        var onLoad = function() {
            fitZoom = map.getBoundsZoom(drawnItems.getBounds());
            map.setZoom(fitZoom <= 9 ? fitZoom - 1 : 9);
            tileLayer.off('load', onLoad);
        };
        tileLayer.on('load', onLoad);
        var id="M012:HK19930418:11";
        $.getJSON('https://ajapaik.ee/api/v1/source/?query=' + id, function (data) {
            if (typeof(data) !== "undefined" && typeof(data.photos) !== "undefined") {
                $.each( data.photos, function( key, p ) {
                    if (typeof(p.latitude) !== "undefined" && typeof(p.longitude) !== "undefined") {
                        var icon = L.divIcon({
                            className: 'mapMarker',
                            iconSize: null,
                            html: '<div class="leaflet-marker-icon leaflet-zoom-animated leaflet-interactive" style="margin-left: -10px; margin-top: -30px;"><i class="fa fa-map-marker" style="position: relative; font-size: 35px; opacity: 0.8; color:green"></i></div>'
                        });

                       L.marker([p.latitude, p.longitude], {icon: icon}).addTo(map);
                    }
                });
            }
        });

    }

})();