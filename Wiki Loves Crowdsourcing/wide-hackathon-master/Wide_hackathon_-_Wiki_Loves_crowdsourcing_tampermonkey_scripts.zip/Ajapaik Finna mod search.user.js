// ==UserScript==
// @name         Ajapaik Finna mod search
// @namespace    https://www.finna.fi/Search/Results
// @version      0.1
// @description  Inject
// @author       You
// @match        https://www.finna.fi/Search/Results*
// @grant GM_addStyle
// @require http://code.jquery.com/jquery-latest.js
// @run-at document-end

// ==/UserScript==

(function() {
    'use strict';
//    $(document).ready(function() {
        var e=$('A[href="/Record/musketti.M012:HK19930418:12"]').closest("div.media");
        if (e.length) {
            e.find("img.recordcover").attr("src", "https://ajapaik.ee/media/uploads/Ajapaik-rephoto-2018-09-21_12-51-08.jpg");
            e.find("a.image-popup-trigger").find("div.iconlabel").hide();
            e.find(".recordcover").click(function (event) { event.stopPropagation(); document.location="https://www.finna.fi/Record/musketti.M012:HK19930418:12"; });
            e.find("a.image-popup-trigger").removeClass("image-popup-trigger");
            e.find("a.title").html("<b>Jälleenvalokuva valokuvasta punavankeja Suomenlinnan IV piirin Susisaaren vankileirillä musketti.M012:HK19930418:11</b>");
            e.find("div.dateyeartype").find(".truncate-field").text("Teemu Ikonen");
            e.find("div.dateyeartype").html(e.find("div.dateyeartype").html().replace("1918", "2018"))
            e.find("div.dateyeartype").html(e.find("div.dateyeartype").html().replace("Kuva", "Jälleenvalokuva"))
            e.find(".result-body").find("span.highlight").text("Suomenlinna");



        }
        GM_addStyle('img.recordcover { display:block !important}');
        GM_addStyle('div.right { display:block !important}');
//    });
    $(document).ready(function() {
        GM_addStyle('div.right { display:block !important}');
    });

})();